EmployeeManager
===============

MySQL employee database manager for CS480. Instructions for this assignment are in instructions.pdf

Run ant to build .jar.

##How to run


Create a file called transfile in the same directory as the jar and run 

`java -jar mdumfo2_CS480HW4.jar database username password`

- database is the name of the database you want to connect to.
- username is your username for the database.
- password is your password for the database.

